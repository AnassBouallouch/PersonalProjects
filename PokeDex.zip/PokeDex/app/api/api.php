<?php
//
//include_once 'app/helper.php';
//require 'vendor/autoload.php';
//
//$apiUrl = 'https://pokeapi.co/api/v2/';
//
//$guzzle = new GuzzleHttp\Client();
//$response = $guzzle->get($apiUrl.'pokemon/charizard');
////$response2 = $guzzle->get($apiUrl.'pokemon/rattata');
////$response3 = $guzzle->get($apiUrl.'pokemon/blastoise');
////$response4 = $guzzle->get($apiUrl.'pokemon/pikachu');
////$response5 = $guzzle->get($apiUrl.'pokemon/charmander');
////$response6 = $guzzle->get($apiUrl.'pokemon/squirtle');
////$response7 = $guzzle->get($apiUrl.'pokemon/jigglypuff');
//
//
//
//$pokemon = json_decode($response->getBody()->getContents(), true);
////$pokemon2 = json_decode($response2->getBody()->getContents(), true);
////$pokemon3 = json_decode($response3->getBody()->getContents(), true);
////$pokemon4 = json_decode($response4->getBody()->getContents(), true);
////$pokemon5 = json_decode($response5->getBody()->getContents(), true);
////$pokemon6 = json_decode($response6->getBody()->getContents(), true);
////$pokemon7 = json_decode($response7->getBody()->getContents(), true);
//
//
//$pokemons = [];
//
//$pokemons[] = [
//  'name' => $pokemon['name'],
//  'types' => array_map(fn($ability) => $ability['ability']['name'], $pokemon['abilities']),
//  'picture' => $pokemon['sprites']['front_default']
//];
////$pokemons[] = [
////    'name' => $pokemon2['name'],
////    'types' => array_map(fn($ability) => $ability['ability']['name'], $pokemon2['abilities']),
////    'picture' => $pokemon2['sprites']['front_default']
////];
////$pokemons[] = [
////    'name' => $pokemon3['name'],
////    'types' => array_map(fn($ability) => $ability['ability']['name'], $pokemon3['abilities']),
////    'picture' => $pokemon3['sprites']['front_default']
////];
////$pokemons[] = [
////    'name' => $pokemon4['name'],
////    'types' => array_map(fn($ability) => $ability['ability']['name'], $pokemon4['abilities']),
////    'picture' => $pokemon4['sprites']['front_default']
////];
////
////$pokemons[] = [
////    'name' => $pokemon5['name'],
////    'types' => array_map(fn($ability) => $ability['ability']['name'], $pokemon5['abilities']),
////    'picture' => $pokemon5['sprites']['front_default']
////];
////
////$pokemons[] = [
////    'name' => $pokemon6['name'],
////    'types' => array_map(fn($ability) => $ability['ability']['name'], $pokemon6['abilities']),
////    'picture' => $pokemon6['sprites']['front_default']
////];
////
////$pokemons[] = [
////    'name' => $pokemon7['name'],
////    'types' => array_map(fn($ability) => $ability['ability']['name'], $pokemon7['abilities']),
////    'picture' => $pokemon7['sprites']['front_default']
////];
////
//
//
//return $pokemons;