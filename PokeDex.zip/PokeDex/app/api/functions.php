<?php

function makeApiRequest(array $options = [])
{
    $apiUrl = 'https://pokeapi.co/api/v2/pokemon';
    $apiUrl .= '?'.http_build_query([
        'limit' => $options['limit']  ?? 6,
        'offset' => $options ['offset'] ?? 0
    ]);

    $guzzle = new GuzzleHttp\Client();
    $response = $guzzle->get($apiUrl);

    $collection = json_decode($response->getBody()->getContents(), true)['results'];

    $pokemon = resultsToCollection($collection);

    return $pokemon;
}

function resultsToCollection(array $collection)
{
    return array_map(function($pokemon) {

        $guzzle = new \GuzzleHttp\Client();
        $response = $guzzle->get($pokemon['url']);
        $response = json_decode($response->getBody()->getContents(), true);

        $data = [
            'name' => $pokemon['name'],
            'type' => $response['types'][0]['type']['name'],
            'id' => str_pad($response['id'], 3, '0', STR_PAD_LEFT),
            'image' => $response['sprites']['front_default']
        ];

        file_put_contents('public/cache/pokemon.cache', json_encode(['pokemons' => $data]));
    }, $collection);

}

function getPokemons()
{
    return json_decode(file_get_contents('public/cache/pokemon.cache'), true)['pokemons'];
}